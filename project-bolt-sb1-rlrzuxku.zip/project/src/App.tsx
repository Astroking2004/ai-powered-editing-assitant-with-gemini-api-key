import React, { useState } from 'react';
import { Wand2, Loader2, Key, AlertCircle, CreditCard } from 'lucide-react';

function App() {
  const [apiKey, setApiKey] = useState('');
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleEdit = async () => {
    if (!apiKey) {
      setError('Please enter your Google AI API key');
      return;
    }
    if (!input.trim()) {
      setError('Please enter some text to edit');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=' + apiKey, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: `Please improve the following text while maintaining its original meaning. Focus on clarity, grammar, and style: ${input}`
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2000,
          },
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'API request failed');
      }

      const data = await response.json();
      setOutput(data.candidates[0]?.content?.parts[0]?.text || 'No suggestion available');
    } catch (err) {
      if (err instanceof Error) {
        if (err.message.toLowerCase().includes('quota') || err.message.includes('429')) {
          setError(
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-red-300" />
                <span className="font-semibold">API Quota Exceeded</span>
              </div>
              <p>You have exceeded your Google AI API quota. To resolve this:</p>
              <ol className="list-decimal list-inside space-y-1 ml-2">
                <li>Visit the <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300 underline">Google Cloud Console</a></li>
                <li>Check your API quotas and limits</li>
                <li>Enable billing if needed</li>
                <li>Consider upgrading your plan for higher limits</li>
              </ol>
            </div>
          );
        } else if (err.message.toLowerCase().includes('billing') || err.message.toLowerCase().includes('payment')) {
          setError(
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-red-300" />
                <span className="font-semibold">Billing Required</span>
              </div>
              <p>Your Google Cloud project requires billing setup. To resolve this:</p>
              <ol className="list-decimal list-inside space-y-1 ml-2">
                <li>Visit the <a href="https://console.cloud.google.com/billing" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300 underline">Google Cloud Billing Console</a></li>
                <li>Set up a billing account</li>
                <li>Link it to your project</li>
                <li>Enable the Gemini API for your project</li>
              </ol>
              <p className="mt-2 text-sm text-gray-400">Note: New accounts get free credits to start with.</p>
            </div>
          );
        } else {
          setError('Error: ' + err.message);
        }
      } else {
        setError('An unexpected error occurred');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-8">
          <Wand2 className="w-8 h-8 mr-3" />
          <h1 className="text-3xl font-bold">AI Writing Assistant</h1>
        </div>

        <div className="mb-6">
          <div className="flex items-center mb-2">
            <Key className="w-4 h-4 mr-2" />
            <label className="text-sm font-medium">Google AI API Key</label>
          </div>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="Enter your Google AI API key"
            className="w-full p-3 rounded-lg bg-gray-800 border border-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium mb-2">Original Text</label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Enter text to edit..."
              className="w-full h-64 p-3 rounded-lg bg-gray-800 border border-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Improved Version</label>
            <textarea
              value={output}
              readOnly
              className="w-full h-64 p-3 rounded-lg bg-gray-800 border border-gray-700 outline-none resize-none"
              placeholder="AI suggestions will appear here..."
            />
          </div>
        </div>

        {error && (
          <div className="mt-4 p-4 bg-red-900/50 border border-red-700 rounded-lg text-red-200">
            {error}
          </div>
        )}

        <button
          onClick={handleEdit}
          disabled={isLoading}
          className="mt-6 w-full py-3 px-6 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <Wand2 className="w-5 h-5 mr-2" />
              Improve Text
            </>
          )}
        </button>
      </div>
    </div>
  );
}

export default App;